# Brief Codex — Clôture Therrien PREMIUM

## Rôle et mandat

Tu reçois une base de code fonctionnelle. **Conserver tout ce qui marche; éviter les régressions.** Produire un site réellement élégant, particulièrement sur iPhone, avec un studio 2D de clôtures photoréaliste et des interactions intuitives accessibles. L'utilisateur vise un niveau visuel comparable aux pages produits Apple et aux agences d'architecture haut de gamme : grandes photographies, rythme, typographie, détails de finition, animations discrètes, transitions fluides et zéro surcharge visuelle.

## État initial : déjà implémenté

- `index.html` et CSS responsifs.
- Cinq familles de clôtures et un moteur SVG illustratif (`src/features/fence-svg.js`).
- Contrôles de modèle / couleur / hauteur / longueur.
- Mode « Jour / Heure dorée », comparateur avant/après, export PNG, configuration partageable, état local.
- Modale de demande, consentement, mode démo explicite (aucun envoi réel sans endpoint).
- `npm test` : tests de configuration et génération SVG.

## Objectif qualité visuelle — prioritaires

1. **Studio réaliste.** Améliorer considérablement la perspective et les jonctions avec le sol. Les panneaux doivent rester plausibles dans la photographie : pas d'impression de calque flottant. Adapter les dimensions selon profondeur, ajouter ombres au sol et éclairage, gérer cas du verre semi-transparent. Ne pas laisser croire à un outil d'ingénierie ou de conformité.
2. **Plusieurs scènes sélectionnables.** Proposer des cours paysagées réelles (cour moderne avec piscine, patio en bois, jardin contemporain). Utiliser des assets autorisés ou générés spécifiquement; proposer préchargement et optimisation WebP/AVIF. Assurer un même calage de la clôture sur les vues de scènes.
3. **Convivialité.** Rendre le flux « choisir → personnaliser → comparer → partager → soumission » instantanément évident sans tutoriel, avec plus gros targets tactiles sur mobile.
4. **Marque haut de gamme.** Raffiner espacements, tailles de caractères, états hover/focus, micro-interactions, images de collection propres au matériau, réduction de poids des fontes et stratégie de chargement des assets.
5. **Formulaire de soumission réel et sécurisé.** Concevoir un endpoint serverless séparé, ajouter validation backend, anti-spam, limitation de débit, suivi des erreurs; n'activer `quoteEndpoint` qu'une fois la délivrabilité vérifiée et avec permission du propriétaire. Respecter Loi 25 / vie privée / consentement. **Aucune clé API côté client.**
6. **Préparation SEO et production.** Métadonnées OG adaptées au domaine final, sitemap, favicon original autorisé, données structurées seulement avec informations vérifiées, analytics respectueux de la vie privée avec consentement si nécessaire, contenu rédigé en bon français du Québec.

## Contraintes non négociables

- **Ne pas copier** les assets ou le code privé du site historique; concevoir un site original, avec permission du propriétaire pour utiliser sa marque.
- Réutiliser les modules actuels quand possible; refactorer seulement si les tests de non-régression passent.
- Pas de faux prix, faux avis clients, faux labels de conformité, fausses certifications ni prétention de « devis instantané ».
- Les noms et couleurs du composite inspirés des teintes publiques EZFENCE doivent être confirmés (la représentation couleur reste approximative).
- Les hauteurs proposées sont une prévisualisation d'ambiance, pas un avis sur les exigences de sécurité d'une piscine.
- Maintenir le chemin relatif des fichiers pour un déploiement sous `https://username.github.io/nom-repo/`.
- Contrôles accessibles au clavier; dialogue correctement focusé; états aria-pressed fidèles.
- Séparer code de présentation, données catalogue, logique du configurateur et intégration du formulaire.

## Tests de régression manuels à effectuer après chaque étape

- Initialisation : composite teck 5 pi, une clôture visible, aucun message console.
- Chacune des cinq familles change réellement de forme (pas seulement de couleur).
- Changer de finition modifie la clôture; changer de modèle choisit une finition valide.
- Les trois hauteurs modifient la géométrie; le sélecteur de longueur ne fait pas semblant de modifier la longueur visible (la valeur est un renseignement au devis).
- La réglette compare le même décor avec / sans clôture, clavier et glisser.
- Heure dorée agit sur l'ambiance; le lien de partage préserve les choix pertinents.
- L'export PNG produit une image ouvrable. Vérifier au moins Chrome, Safari iOS.
- Clic sur une carte collection : sélection du bon matériau et défilement vers le studio.
- La demande récapitule la configuration choisie. Si endpoint absent, **aucune transmission automatique** et message d'information explicite.
- Menu mobile, tailles 390 px / 768 px / 1440 px, pas de défilement horizontal.
- Respect des préférences `prefers-reduced-motion` et absence d'animations essentielles.

## Ordre de travail conseillé

1. Exécuter les tests et prendre des captures avant modification.
2. Rendre le configurateur et les images plus crédibles.
3. Perfectionner l'ergonomie sur mobile.
4. Mettre les vraies fiches de produits et photos approuvées.
5. Relier le serveur de soumissions et tester l'envoi avec consentement.
6. Compléter les tests automatiques et réviser l'accessibilité, le poids, la SEO.

## Définition de « fini »

Une personne découvre le site sans explication, choisit un produit, explore des finitions, visualise une clôture crédible dans une jolie cour sur mobile, peut comparer et exporter, et transmet sa demande à un vrai canal sécurisé (seulement après connexion validée). Le tout fonctionne sur GitHub Pages ou un hébergement adapté au backend, sans régression des fonctionnalités existantes.
