/**
 * 2D fence renderer (pure function, no browser dependency).
 * Its 1600 × 900 coordinates are aligned to the original courtyard photo.
 * This is a mood-board illustration, NOT dimensional, structural or code-compliant plans.
 */
import { MATERIAL_BY_ID } from '../data/catalog.js';
import { normalizeConfig } from '../lib/config.js';

const FRAME = Object.freeze({ left: 113, right: 1487, base: 588, sections: 7 });

function tint(color, amount) {
  const raw = color.replace('#', '');
  const rgb = [0, 2, 4].map((n) => parseInt(raw.slice(n, n + 2), 16));
  const next = rgb.map((channel) => {
    const mixed = amount >= 0 ? channel + (255 - channel) * amount : channel * (1 + amount);
    return Math.round(Math.max(0, Math.min(255, mixed))).toString(16).padStart(2, '0');
  });
  return `#${next.join('')}`;
}

function rect(x, y, width, height, fill, extra = '') {
  return `<rect x="${x}" y="${y}" width="${width}" height="${height}" fill="${fill}" ${extra}/>`;
}

function sectionArtwork(style, x, width, top, base, color, index, prefix) {
  const innerX = x + 9;
  const innerW = width - 18;
  const innerTop = top + 9;
  const innerBottom = base - 9;
  const innerHeight = innerBottom - innerTop;
  const baseColor = tint(color, -0.07);
  const shine = tint(color, 0.16);
  let markup = '';

  if (style === 'composite') {
    markup += rect(innerX, innerTop, innerW, innerHeight, tint(color, -0.3));
    const rows = Math.max(7, Math.round(innerHeight / 19));
    const boardHeight = (innerHeight - (rows - 1) * 3.1) / rows;
    for (let row = 0; row < rows; row += 1) {
      const y = innerTop + row * (boardHeight + 3.1);
      markup += rect(innerX + 1, y, innerW - 2, boardHeight, row % 3 === 1 ? color : baseColor,
        `stroke="${tint(color, -0.2)}" stroke-width=".7"`);
      markup += `<path d="M${innerX + 5} ${y + 2.6}h${innerW - 13}" stroke="${shine}" opacity=".26" stroke-width="1"/>`;
      // Very subtle grain, intentionally not repeating a fake photographic texture.
      if (row % 2 === 0) markup += `<path d="M${innerX + 27} ${y + boardHeight * 0.7}h${innerW * 0.55}" stroke="${shine}" opacity=".14"/>`;
    }
    markup += rect(innerX - 3, top + 4, innerW + 6, 6, tint(color, -0.22));
  } else if (style === 'ornamental') {
    const barW = 8;
    const count = 11;
    const interval = (innerW - barW) / (count - 1);
    markup += rect(innerX, top + 35, innerW, 7, baseColor);
    markup += rect(innerX, base - 41, innerW, 7, baseColor);
    for (let bar = 0; bar < count; bar += 1) {
      const bx = innerX + bar * interval;
      markup += rect(bx, top + 8, barW, innerBottom - top + 2, bar % 2 ? color : baseColor, `rx="1"`);
      markup += rect(bx + 1, top + 8, 1.5, innerBottom - top + 2, shine, `opacity=".28"`);
    }
  } else if (style === 'mesh') {
    const clip = `${prefix}-mesh-clip-${index}`;
    markup += `<clipPath id="${clip}">${rect(innerX, top + 17, innerW, base - top - 26, '#fff')}</clipPath>`;
    markup += `<g clip-path="url(#${clip})">`;
    markup += rect(innerX, top + 17, innerW, base - top - 26, color, 'opacity=".055"');
    markup += rect(innerX, top + 17, innerW, base - top - 26, `url(#${prefix}-chain-mesh)`);
    markup += `</g>`;
    markup += rect(innerX, top + 16, innerW, 5, baseColor);
    markup += rect(innerX, base - 13, innerW, 4, baseColor);
    markup += `<path d="M${innerX + innerW / 2} ${top + 18}V${base - 10}" stroke="${color}" stroke-width="3" opacity=".9"/>`;
  } else if (style === 'glass12') {
    markup += rect(innerX + 3, top + 8, innerW - 6, innerHeight - 2, '#c9e4e7', 'fill-opacity=".22" stroke="#f0ffff" stroke-opacity=".62" stroke-width="2.3"');
    markup += `<path d="M${innerX + 9} ${top + 11}v${innerHeight - 10}" stroke="white" stroke-opacity=".40" stroke-width="4"/>`;
    markup += `<path d="M${innerX + 7} ${top + 12}h${innerW - 12}" stroke="white" stroke-opacity=".62" stroke-width="2"/>`;
    for (let clamp = 0; clamp < 2; clamp += 1) {
      const cx = innerX + 35 + clamp * (innerW - 74);
      markup += rect(cx, base - 17, 11, 21, color, 'rx="2"');
      markup += rect(cx + 2, base - 16, 2, 14, shine, 'opacity=".6"');
    }
  } else if (style === 'glass6') {
    markup += rect(innerX, innerTop, innerW, innerHeight, '#c8e5e6', `fill-opacity=".2" stroke="${color}" stroke-width="5"`);
    markup += `<path d="M${innerX + 3} ${innerTop + 3}L${innerX + innerW * 0.26} ${innerTop + 3}L${innerX + innerW * 0.12} ${innerBottom - 3}" fill="white" opacity=".07"/>`;
    markup += rect(innerX - 1, top + 8, innerW + 2, 6, baseColor);
    markup += rect(innerX - 1, base - 13, innerW + 2, 6, baseColor);
  }
  return markup;
}

/** Returns a full SVG document string for DOM injection and PNG export. */
export function createFenceSvg(rawConfig, { accessible = false, idPrefix = 'main' } = {}) {
  const config = normalizeConfig(rawConfig);
  const material = MATERIAL_BY_ID.get(config.materialId);
  const finish = material.finishes.find((entry) => entry.id === config.finishId);
  const color = finish.color;
  const top = FRAME.base - { 4: 140, 5: 170, 6: 198 }[config.heightFt];
  const bayWidth = (FRAME.right - FRAME.left) / FRAME.sections;
  let body = '';

  for (let index = 0; index < FRAME.sections; index += 1) {
    const x = FRAME.left + index * bayWidth;
    body += sectionArtwork(material.id, x, bayWidth, top, FRAME.base, color, index, idPrefix);
  }

  // Glass 12 mm uses compact ground clamps and no continuous full-height posts.
  if (material.id !== 'glass12') {
    for (let index = 0; index <= FRAME.sections; index += 1) {
      const x = FRAME.left + index * bayWidth - 7;
      const postTop = top - (material.id === 'ornamental' ? 8 : 5);
      body += rect(x, postTop, 14, FRAME.base - postTop + 7, tint(color, -0.28), 'rx="1.5"');
      body += rect(x + 2.5, postTop + 3, 3.5, FRAME.base - postTop - 2, tint(color, 0.16), 'opacity=".56"');
      body += rect(x - 2, postTop - 3, 18, 6, tint(color, -0.2), 'rx="1.4"');
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" ${accessible ? `role="img" aria-label="Aperçu 2D d’une clôture ${material.name}"` : 'aria-hidden="true"'}>
    <defs>
      <pattern id="${idPrefix}-chain-mesh" width="24" height="24" patternUnits="userSpaceOnUse">
        <path d="M12 0L24 12L12 24L0 12L12 0Z" fill="none" stroke="${color}" stroke-opacity=".84" stroke-width="2" />
      </pattern>
      <filter id="${idPrefix}-fence-shadow" x="-5%" y="-40%" width="110%" height="160%"><feDropShadow dx="2" dy="7" stdDeviation="4" flood-color="#122218" flood-opacity=".34"/></filter>
    </defs>
    <ellipse cx="800" cy="594" rx="714" ry="26" fill="#15271a" opacity=".13"/>
    <g filter="url(#${idPrefix}-fence-shadow)">${body}</g>
  </svg>`;
}

/** Small original illustrations for the product tiles, using the same engine. */
export function createMiniatureSvg(materialId) {
  const material = MATERIAL_BY_ID.get(materialId);
  const config = normalizeConfig({ materialId, finishId: material.finishes[0].id, heightFt: 5 });
  const graphic = createFenceSvg(config, { idPrefix: `tile-${materialId}` });
  // Extract its content to avoid nested SVG and preserve transparent/fence layers.
  const inner = graphic.slice(graphic.indexOf('>') + 1, graphic.lastIndexOf('</svg>'));
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 260" aria-hidden="true">
    <defs><linearGradient id="sky-${materialId}" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#e5e8e1"/><stop offset="1" stop-color="#cbd7c7"/></linearGradient></defs>
    <rect width="480" height="260" fill="url(#sky-${materialId})"/>
    <path d="M0 133Q140 115 245 133T480 130V260H0Z" fill="#9db191"/>
    <path d="M0 185Q200 155 480 185V260H0Z" fill="#718f67"/>
    <g opacity=".72"><circle cx="31" cy="127" r="45" fill="#77916c"/><circle cx="444" cy="119" r="54" fill="#758f6d"/></g>
    <g transform="scale(.30)">${inner}</g>
    <rect x="0" y="236" width="480" height="24" fill="#d8d5c8"/>
  </svg>`;
}
