# Clôture Therrien — Concept premium + studio 2D

Une refonte **indépendante et non officielle** de [cloturetherrien.com](https://cloturetherrien.com/), développée à partir de zéro comme prototype propre, maintenable et déployable sur GitHub Pages. Le code original privé du site n'est pas inclus.

## Démarrage en 30 secondes

Ce projet est volontairement **sans dépendance npm ni compilation** : HTML, CSS, JavaScript ES modules et SVG natif. Ouvrir `index.html` directement avec `file://` peut bloquer les modules JS; lancer un petit serveur local.

```bash
cd cloture-therrien-codex
python3 -m http.server 4173
# puis ouvrir http://localhost:4173
```

Avec Node.js 20+ installé :

```bash
npm test
npm run dev
```

## Fonctionnalités livrées

- Site vitrine premium en français du Québec, responsive (desktop / tablette / téléphone).
- Section d'accueil, cinq collections, présentation de l'approche, appels à l'action.
- Studio 2D dans une cour paysagée **créée spécialement pour le concept**.
- Cinq familles présentées publiquement par Clôture Therrien : composite EZFENCE, ornemental aluminium, verre trempé 6 et 12 mm, mailles de chaîne.
- Moteur de rendu de clôture vectorielle SVG **original** : types de panneaux, poteaux, barreaux, treillis, verre, couleur et hauteur.
- Finitions, hauteur illustrative (4, 5 ou 6 pi), longueur approximative (10 à 150 pi), ambiance « jour / heure dorée ».
- Comparaison avant/après au glisser, contrôlable aussi au clavier via une réglette.
- Export de l'illustration configurée en PNG (pas un plan à l'échelle).
- Lien de partage qui encode le choix des matériaux, finitions et dimensions dans l'URL.
- Sauvegarde automatique des préférences du studio dans le navigateur (localStorage).
- Formulaire lié aux choix de l'utilisateur, validations HTML natives, consentement et champ leurre antibot.
- **Mode démonstration** sécurisé par défaut : formulaire prépare une demande et propose la copie ou l'ouverture du client courriel. Il ne prétend **pas** envoyer un message.

## Arborescence

```text
.
├── index.html                 # Structure sémantique du site et formulaire dialog
├── assets/
│   └── cour-signature.webp   # Illustration d'ambiance générée pour ce projet
├── src/
│   ├── app.js                 # Assemblage, navigation, collections
│   ├── data/
│   │   ├── catalog.js        # Catalogue éditorial + teintes illustratives
│   │   └── site-config.js    # Configuration de l'endpoint de contact
│   ├── features/
│   │   ├── fence-svg.js       # Moteur de dessin SVG sans DOM
│   │   ├── visualizer.js      # État du studio, contrôles, export PNG
│   │   └── quote.js          # Formulaire et envoi/démo
│   ├── lib/
│   │   └── config.js         # Validation, URL et sauvegarde de configuration
│   └── styles/
│       ├── base.css
│       ├── components.css
│       └── responsive.css
├── tests/
│   └── visualizer.test.js     # Tests du moteur de rendu et validation des entrées
├── CODEX_BRIEF.md            # Plan d'amélioration et critères d'acceptation
└── package.json
```

## Important : préparation avant la mise en production

### Brancher l'envoi réel des demandes

Dans `src/data/site-config.js`, `quoteEndpoint` vaut `''` par défaut. **Aucune soumission n'est envoyée** sans URL HTTPS définie. L'endpoint doit accepter une requête JSON `POST` depuis votre origine Web, gérer la validation côté serveur, la protection anti-spam, les protections de données personnelles (notamment la Loi 25 du Québec), et retourner un vrai code HTTP `2xx` uniquement si la demande a été traitée correctement.

> Exemple : utiliser une fonction serverless (Cloudflare Workers, Supabase Edge Function, Netlify Function) branchée à un service courriel transactionnel. **Ne jamais exposer une clé secrète dans `site-config.js`**. La configuration/gestion des consentements et des données est une responsabilité du propriétaire du site.

### Vérifier les informations avant de publier

- Obtenir l'autorisation du propriétaire pour l'utilisation de la marque et la mise en ligne.
- Valider les vraies couleurs, hauteurs, gardes et modèles; les teintes sont des approximations artistiques.
- Ajouter de vraies photos de chantiers avec accord de diffusion pour les sections projets et collections.
- Vérifier la conformité aux règles de clôture et d'accès aux piscines applicables; l'outil n'évalue **aucune** conformité réglementaire.
- Confirmer la politique de confidentialité, la conservation des données et le texte de consentement.
- Vérifier les liens vers le site historique si remplacé.

## GitHub Pages

1. Pousser **le contenu de ce dossier** à la racine d'un dépôt GitHub (ex. `cloture-therrien-premium`).
2. Dans le dépôt GitHub : **Settings → Pages → Deploy from a branch → main / (root)**.
3. Attendre l'URL `https://COMPTE.github.io/NOM-DU-DEPOT/`.
4. Les chemins des fichiers sont relatifs (`./`), compatibles avec GitHub Pages à la racine d'un sous-chemin.
5. Avant de rendre un site public, vérifier l'autorisation du propriétaire de la marque et le statut « concept ».

## Qualité & vérifications

```bash
npm test
```

Le projet a été testé en mode navigateur desktop 1440px et mobile 390px : génération des cinq cartes et des cinq modèles, sélection du verre 12 mm, comparateur, modification du pourcentage, ouverture et validation du formulaire. Voir `CODEX_BRIEF.md` pour les tests de régression à conserver.

## Crédits et origine des contenus

- L'illustration de cour `cour-signature.webp` a été créée pour ce concept; ce n'est pas une photographie d'un chantier Clôture Therrien.
- Les pictogrammes et visualisations de clôture sont générés en SVG par le code et ne réutilisent pas le code ou les images du site existant.
- Les familles de produits et coordonnées de l'entreprise proviennent des pages publiques de [Clôture Therrien — clôtures](https://cloturetherrien.com/clotures) et [Contact](https://cloturetherrien.com/contact).
- La marque Clôture Therrien demeure la propriété de ses ayants droit. Ce projet n'est pas un site officiel.
