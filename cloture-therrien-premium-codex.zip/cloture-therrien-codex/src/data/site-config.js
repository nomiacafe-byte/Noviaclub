/**
 * Delivery configuration.
 * Empty quoteEndpoint = demo mode; never pretends to deliver messages.
 * Set a verified, authorized HTTPS endpoint (e.g. Formspree) before launch.
 * API credentials must NEVER appear in client-side code.
 */
export const SITE_CONFIG = Object.freeze({
  quoteEndpoint: '',
});
