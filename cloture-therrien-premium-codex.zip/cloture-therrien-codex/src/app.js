/** Main composition root: feature modules remain independently maintainable. */
import { MATERIALS } from './data/catalog.js';
import { loadConfig } from './lib/config.js';
import { createMiniatureSvg } from './features/fence-svg.js';
import { createVisualizer } from './features/visualizer.js';
import { initQuote } from './features/quote.js';

function initToast() {
  const toast = document.querySelector('#toast');
  let timeoutId;
  return (message) => {
    window.clearTimeout(timeoutId);
    toast.textContent = message;
    toast.classList.add('show');
    timeoutId = window.setTimeout(() => toast.classList.remove('show'), 3400);
  };
}

function initNavigation() {
  const menu = document.querySelector('#menu-button');
  const nav = document.querySelector('#main-nav');
  function setOpen(open) {
    nav.classList.toggle('open', open);
    menu.setAttribute('aria-expanded', String(open));
    menu.setAttribute('aria-label', open ? 'Fermer le menu' : 'Afficher le menu');
  }
  menu.addEventListener('click', () => setOpen(!nav.classList.contains('open')));
  nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => setOpen(false)));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') setOpen(false);
  });
}

function initCollections(visualizer) {
  const collection = document.querySelector('#collection-grid');
  collection.innerHTML = MATERIALS.map((material) => `
    <button type="button" class="collection-card" data-collection="${material.id}" aria-label="Essayer ${material.name} dans le studio">
      <span class="collection-image">${createMiniatureSvg(material.id)}</span>
      <span class="collection-content">
        <span class="collection-number">COLLECTION / ${material.number}</span>
        <h3>${material.name}</h3>
        <p>${material.caption}</p>
        <span class="collection-view">Essayer ce modèle <span aria-hidden="true">↗</span></span>
      </span>
    </button>`).join('');
  collection.addEventListener('click', (event) => {
    const target = event.target.closest('[data-collection]');
    if (!target) return;
    visualizer.selectMaterial(target.dataset.collection);
    document.querySelector('#studio').scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' });
  });
}

function main() {
  document.querySelector('#year').textContent = String(new Date().getFullYear());
  const toast = initToast();
  initNavigation();
  const visualizer = createVisualizer(loadConfig(), { toast });
  initCollections(visualizer);
  initQuote({ getConfig: visualizer.getConfig, toast });
}

main();
