import assert from 'node:assert/strict';
import test from 'node:test';
import { MATERIALS } from '../src/data/catalog.js';
import { createFenceSvg } from '../src/features/fence-svg.js';
import { normalizeConfig, DEFAULT_CONFIG } from '../src/lib/config.js';

test('catalogue contains five official product families', () => {
  assert.equal(MATERIALS.length, 5);
  assert.equal(new Set(MATERIALS.map(({ id }) => id)).size, 5);
});

test('invalid shared configuration is normalized safely', () => {
  const config = normalizeConfig({ materialId: '<b>x</b>', finishId: 'hacked', heightFt: 9000, lengthFt: -22, comparePercent: 1000 });
  assert.equal(config.materialId, DEFAULT_CONFIG.materialId);
  assert.equal(config.heightFt, 5);
  assert.equal(config.lengthFt, 10);
  assert.equal(config.comparePercent, 95);
});

test('changing material resets unsupported finish', () => {
  const config = normalizeConfig({ materialId: 'glass12', finishId: 'teck', heightFt: 4 });
  assert.equal(config.finishId, 'inox');
  assert.equal(config.heightFt, 4);
});

test('each material generates a self-contained SVG preview', () => {
  for (const material of MATERIALS) {
    const svg = createFenceSvg({ materialId: material.id, finishId: material.finishes[0].id }, { idPrefix: `test-${material.id}` });
    assert.match(svg, /<svg\s/);
    assert.match(svg, /<\/svg>/);
    assert.match(svg, /viewBox="0 0 1600 900"/);
    assert.doesNotMatch(svg, /undefined|NaN/);
  }
});

test('fence model visibly changes for different heights and finishes', () => {
  const tall = createFenceSvg({ materialId: 'composite', finishId: 'teck', heightFt: 6 });
  const short = createFenceSvg({ materialId: 'composite', finishId: 'teck', heightFt: 4 });
  const dark = createFenceSvg({ materialId: 'composite', finishId: 'ipe', heightFt: 6 });
  assert.notEqual(tall, short);
  assert.notEqual(tall, dark);
});
