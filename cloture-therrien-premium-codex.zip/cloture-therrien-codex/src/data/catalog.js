/**
 * Catalogue éditorial du prototype.
 * Les familles correspondent aux produits affichés publiquement sur cloturetherrien.com.
 * Les teintes sont illustratives et doivent être validées avec le fournisseur.
 * Aucune donnée de prix ni de conformité n'est inférée ici.
 */
export const MATERIALS = Object.freeze([
  {
    id: 'composite', number: '01', name: 'Composite EZFENCE', short: 'Composite',
    caption: 'Le caractère du bois, une allure résolument actuelle.',
    group: 'Intimité', style: 'Lattes horizontales',
    finishes: [
      { id: 'teck', name: 'Teck', color: '#a9774c' },
      { id: 'cedre', name: 'Cèdre rouge', color: '#925a3d' },
      { id: 'chene', name: 'Chêne', color: '#b28b68' },
      { id: 'noyer', name: 'Noyer', color: '#574438' },
      { id: 'ipe', name: 'Ipé', color: '#72533e' },
    ],
  },
  {
    id: 'ornamental', number: '02', name: 'Aluminium ornemental', short: 'Aluminium',
    caption: 'Des lignes fines qui soulignent l’architecture.',
    group: 'Élégance', style: 'Barreaux verticaux',
    finishes: [
      { id: 'noir', name: 'Noir satin', color: '#202727' },
      { id: 'graphite', name: 'Graphite', color: '#4c5556' },
      { id: 'blanc', name: 'Blanc doux', color: '#ecece3' },
    ],
  },
  {
    id: 'glass12', number: '03', name: 'Verre trempé 12 mm', short: 'Verre 12 mm',
    caption: 'La transparence dans sa forme la plus pure.',
    group: 'Transparence', style: 'Panneaux sans cadre supérieur',
    finishes: [
      { id: 'inox', name: 'Inox brossé', color: '#9ca6a4' },
      { id: 'noir', name: 'Noir architectural', color: '#303838' },
    ],
  },
  {
    id: 'glass6', number: '04', name: 'Verre trempé 6 mm', short: 'Verre 6 mm',
    caption: 'La lumière préservée, une structure affirmée.',
    group: 'Légèreté', style: 'Panneaux encadrés',
    finishes: [
      { id: 'graphite', name: 'Graphite', color: '#343b3b' },
      { id: 'blanc', name: 'Blanc', color: '#e3e4dc' },
    ],
  },
  {
    id: 'mesh', number: '05', name: 'Mailles de chaîne', short: 'Mailles',
    caption: 'Une silhouette discrète, une solution éprouvée.',
    group: 'Essentiel', style: 'Treillis losangé',
    finishes: [
      { id: 'noir', name: 'Noir', color: '#313837' },
      { id: 'acier', name: 'Acier', color: '#a4adab' },
      { id: 'blanc', name: 'Blanc', color: '#e9eae4' },
    ],
  },
]);

export const MATERIAL_BY_ID = new Map(MATERIALS.map((material) => [material.id, material]));
export const HEIGHTS = Object.freeze([4, 5, 6]);
export const AMBIANCES = Object.freeze([
  { id: 'day', name: 'Lumière du jour' },
  { id: 'dusk', name: 'Heure dorée' },
]);
export const BUSINESS = Object.freeze({
  phoneDisplay: '418 473-2783',
  phoneHref: 'tel:+14184732783',
  email: 'info@cloturetherrien.com',
  address: '5200, rue Armand-Viau, Québec',
});
