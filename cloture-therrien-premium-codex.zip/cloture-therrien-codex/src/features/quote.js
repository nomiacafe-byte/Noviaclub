/**
 * Quote request workflow. Safe defaults: NO request is sent without an explicit endpoint.
 * In demo mode, the user can copy a complete request or open their email client.
 * A real site must configure an owned endpoint AND verify delivery end-to-end.
 */
import { describeConfig } from '../lib/config.js';
import { SITE_CONFIG } from '../data/site-config.js';
import { BUSINESS } from '../data/catalog.js';

const $ = (selector) => document.querySelector(selector);

function appendChip(container, value) {
  const chip = document.createElement('span');
  chip.textContent = value;
  container.append(chip);
}

function createSummary(config) {
  const details = describeConfig(config);
  return [details.material, details.finish, details.height, details.length];
}

function formatMessage(values, config) {
  const details = describeConfig(config);
  return [
    'Demande de renseignements — Clôture Therrien',
    '',
    `Nom : ${values.name}`,
    `Courriel : ${values.email}`,
    `Téléphone : ${values.phone || 'Non précisé'}`,
    `Ville / secteur : ${values.city || 'Non précisé'}`,
    '',
    `Modèle : ${details.material}`,
    `Finition : ${details.finish}`,
    `Hauteur souhaitée : ${details.height}`,
    `Longueur approximative : ${details.length}`,
    '',
    'Précisions :',
    values.message || 'Aucune précision ajoutée.',
    '',
    'Note : modèle et couleurs choisis dans un outil de visualisation conceptuel.',
  ].join('\n');
}

function showError(element, message) {
  element.classList.add('error');
  element.textContent = message;
}

function showDemoActions(element, message, values, { toast }) {
  element.classList.remove('error');
  element.replaceChildren();
  const lead = document.createElement('p');
  lead.textContent = 'Votre demande est prête. Aucun message n’a été envoyé automatiquement dans cette version de démonstration.';
  const button = document.createElement('button');
  button.className = 'button button-outline';
  button.type = 'button';
  button.textContent = 'Copier ma demande';
  button.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(message);
      toast('Demande copiée.');
    } catch {
      const details = document.createElement('pre');
      details.textContent = message;
      element.append(details);
      toast('Sélectionnez le texte ci-dessous pour le copier.');
    }
  });
  const link = document.createElement('a');
  link.className = 'underlined-link';
  link.textContent = 'Ouvrir mon application courriel ↗';
  link.href = `mailto:${BUSINESS.email}?subject=${encodeURIComponent('Demande de clôture')}&body=${encodeURIComponent(message)}`;
  const disclaimer = document.createElement('small');
  disclaimer.textContent = `Destinataire : ${BUSINESS.email}. Vous devez confirmer l'envoi depuis votre application courriel.`;
  element.append(lead, button, link, disclaimer);
}

export function initQuote({ getConfig, toast }) {
  const dialog = $('#quote-dialog');
  const form = $('#quote-form');
  const summary = $('#quote-selection');
  const feedback = $('#quote-feedback');
  const sendButton = $('#quote-submit');
  const info = $('#quote-info');
  const endpoint = SITE_CONFIG.quoteEndpoint.trim();
  const canSubmit = endpoint.startsWith('https://');

  if (canSubmit) {
    info.textContent = 'Les informations saisies seront envoyées au service de réception des demandes de soumission.';
    sendButton.firstChild.textContent = 'Envoyer ma demande ';
  }

  function open() {
    summary.replaceChildren();
    createSummary(getConfig()).forEach((text) => appendChip(summary, text));
    feedback.replaceChildren();
    feedback.classList.remove('error');
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  }
  function close() {
    if (typeof dialog.close === 'function') dialog.close();
    else dialog.removeAttribute('open');
  }

  document.querySelectorAll('[data-open-quote]').forEach((button) => button.addEventListener('click', open));
  $('#close-quote').addEventListener('click', close);
  dialog.addEventListener('click', (event) => {
    const rectangle = dialog.getBoundingClientRect();
    if (event.clientX < rectangle.left || event.clientX > rectangle.right || event.clientY < rectangle.top || event.clientY > rectangle.bottom) close();
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    feedback.replaceChildren();
    feedback.classList.remove('error');
    if (!form.reportValidity()) return;

    const data = new FormData(form);
    if (String(data.get('website') || '').trim()) return; // Honeypot for bots
    const values = {
      name: String(data.get('name') || '').trim(),
      email: String(data.get('email') || '').trim(),
      phone: String(data.get('phone') || '').trim(),
      city: String(data.get('city') || '').trim(),
      message: String(data.get('message') || '').trim(),
    };
    if (!values.name || !values.email || !form.elements.consent.checked) {
      showError(feedback, 'Veuillez ajouter votre nom, votre courriel et accepter la condition de confidentialité.');
      return;
    }
    const config = getConfig();
    const message = formatMessage(values, config);
    if (!canSubmit) {
      showDemoActions(feedback, message, values, { toast });
      return;
    }

    sendButton.disabled = true;
    sendButton.setAttribute('aria-busy', 'true');
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ ...values, consent: true, configuration: describeConfig(config), messageComplet: message }),
      });
      if (!response.ok) throw new Error(`Réponse serveur : ${response.status}`);
      form.reset();
      feedback.textContent = 'Votre demande a été reçue par le service de soumission. Merci !';
      toast('Demande transmise.');
    } catch (error) {
      console.error('[Soumission] Échec de transmission :', error);
      showError(feedback, 'L’envoi a échoué. Aucun accusé de réception confirmé. Utilisez une autre méthode de contact.');
      const fallback = document.createElement('a');
      fallback.textContent = 'Envoyer par courriel ↗';
      fallback.href = `mailto:${BUSINESS.email}?subject=${encodeURIComponent('Demande de clôture')}&body=${encodeURIComponent(message)}`;
      feedback.append(document.createTextNode(' '), fallback);
    } finally {
      sendButton.disabled = false;
      sendButton.removeAttribute('aria-busy');
    }
  });
}
