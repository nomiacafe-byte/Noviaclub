import { AMBIANCES, HEIGHTS, MATERIALS, MATERIAL_BY_ID } from '../data/catalog.js';
import { DEFAULT_CONFIG, normalizeConfig, saveConfig, shareUrl } from '../lib/config.js';
import { createFenceSvg } from './fence-svg.js';

const $ = (selector) => document.querySelector(selector);

export function createVisualizer(initialState, { toast }) {
  let state = normalizeConfig(initialState);
  let lastMaterialId = null;
  const scene = $('#scene');
  const fenceLayer = $('#fence-layer');
  const compareLine = $('#compare-line');
  const comparePanel = $('#compare-panel');
  const compareRange = $('#compare-range');
  const materialOptions = $('#material-options');
  const finishOptions = $('#finish-options');
  const heightOptions = $('#height-options');
  const photo = $('#scene-photo');

  materialOptions.innerHTML = MATERIALS.map((material) => `
    <button type="button" class="material-choice" data-material="${material.id}" aria-pressed="false">
      <span class="material-choice-icon" aria-hidden="true">${materialIcon(material.id)}</span>
      <span>${material.short}</span>
    </button>`).join('');
  heightOptions.innerHTML = HEIGHTS.map((height) => `
    <button type="button" class="height-choice" data-height="${height}" aria-pressed="false">${height} pi</button>`).join('');

  function update(patch) {
    const next = { ...state, ...patch };
    if (patch.materialId && patch.materialId !== state.materialId) {
      next.finishId = MATERIAL_BY_ID.get(patch.materialId).finishes[0].id;
    }
    state = normalizeConfig(next);
    saveConfig(state);
    render();
  }

  function render() {
    const material = MATERIAL_BY_ID.get(state.materialId);
    const finish = material.finishes.find((item) => item.id === state.finishId);
    fenceLayer.innerHTML = createFenceSvg(state, { idPrefix: 'studio' });
    scene.classList.toggle('dusk', state.ambianceId === 'dusk');
    $('#scene-title').textContent = material.name;
    $('#scene-description').textContent = `${finish.name} · ${state.heightFt} pi (illustratif)`;
    $('#length-output').textContent = `${state.lengthFt} pi`;
    $('#length-input').value = String(state.lengthFt);
    $('#length-input').setAttribute('aria-valuetext', `${state.lengthFt} pieds`);
    materialOptions.querySelectorAll('[data-material]').forEach((button) => {
      const active = button.dataset.material === state.materialId;
      button.classList.toggle('selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
    if (lastMaterialId !== state.materialId) {
      finishOptions.innerHTML = material.finishes.map((item) => `
        <button type="button" class="finish-choice" data-finish="${item.id}" aria-pressed="false">
          <span class="finish-swatch" style="background:${item.color}" aria-hidden="true"></span>${item.name}
        </button>`).join('');
      lastMaterialId = state.materialId;
    }
    finishOptions.querySelectorAll('[data-finish]').forEach((button) => {
      const active = button.dataset.finish === state.finishId;
      button.classList.toggle('selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
    heightOptions.querySelectorAll('[data-height]').forEach((button) => {
      const active = Number(button.dataset.height) === state.heightFt;
      button.classList.toggle('selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
    document.querySelectorAll('[data-ambiance]').forEach((button) => {
      const active = button.dataset.ambiance === state.ambianceId;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    $('#compare-toggle').setAttribute('aria-pressed', String(state.compare));
    comparePanel.hidden = !state.compare;
    compareLine.hidden = !state.compare;
    fenceLayer.style.clipPath = state.compare ? `inset(0 ${100 - state.comparePercent}% 0 0)` : '';
    compareLine.style.left = `${state.comparePercent}%`;
    compareRange.value = String(state.comparePercent);
  }

  materialOptions.addEventListener('click', (event) => {
    const button = event.target.closest('[data-material]');
    if (button) update({ materialId: button.dataset.material });
  });
  finishOptions.addEventListener('click', (event) => {
    const button = event.target.closest('[data-finish]');
    if (button) update({ finishId: button.dataset.finish });
  });
  heightOptions.addEventListener('click', (event) => {
    const button = event.target.closest('[data-height]');
    if (button) update({ heightFt: Number(button.dataset.height) });
  });
  document.querySelectorAll('[data-ambiance]').forEach((button) => button.addEventListener('click', () => {
    if (AMBIANCES.some((item) => item.id === button.dataset.ambiance)) update({ ambianceId: button.dataset.ambiance });
  }));
  $('#length-input').addEventListener('input', (event) => update({ lengthFt: Number(event.target.value) }));
  $('#compare-toggle').addEventListener('click', () => update({ compare: !state.compare }));
  compareRange.addEventListener('input', (event) => update({ comparePercent: Number(event.target.value) }));

  // Accessible range control plus pointer-based dragging directly on the photo.
  // Dragging is active ONLY in compare mode; the canvas otherwise remains scrollable.
  scene.addEventListener('pointerdown', (event) => {
    if (!state.compare || event.target.closest('button')) return;
    scene.setPointerCapture(event.pointerId);
    moveComparator(event);
  });
  scene.addEventListener('pointermove', (event) => {
    if (state.compare && scene.hasPointerCapture(event.pointerId)) moveComparator(event);
  });
  function moveComparator(event) {
    const rect = scene.getBoundingClientRect();
    update({ comparePercent: Math.max(5, Math.min(95, Math.round(((event.clientX - rect.left) / rect.width) * 100))) });
  }

  $('#share-config').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(shareUrl(state)); toast('Lien de votre configuration copié.'); }
    catch { toast('Impossible de copier automatiquement. Utilisez le lien dans la barre d’adresse.'); }
  });
  $('#download-preview').addEventListener('click', () => downloadPreview(state, photo, toast));

  render();
  return {
    getConfig: () => ({ ...state }),
    selectMaterial: (materialId) => {
      if (MATERIAL_BY_ID.has(materialId)) update({ materialId });
    },
    reset: () => update(DEFAULT_CONFIG),
  };
}

function materialIcon(materialId) {
  const common = 'stroke="#667a68" stroke-width="1.5" fill="none"';
  if (materialId === 'composite') return `<svg viewBox="0 0 20 20"><path ${common} d="M2 5h16M2 10h16M2 15h16M4 3v14m12-14v14"/></svg>`;
  if (materialId === 'ornamental') return `<svg viewBox="0 0 20 20"><path ${common} d="M3 5h14M3 15h14M5 2v16m5-16v16m5-16v16"/></svg>`;
  if (materialId === 'mesh') return `<svg viewBox="0 0 20 20"><path ${common} d="M2 2l16 16M-4 2l16 16M8 2l12 12M18 2L2 18M12 2L2 12M20 8L10 18"/></svg>`;
  if (materialId === 'glass12') return `<svg viewBox="0 0 20 20"><path ${common} d="M4 2h12v14H4zM7 5v7M5 18h3m4 0h3"/></svg>`;
  return `<svg viewBox="0 0 20 20"><path ${common} d="M2 2h16v16H2zM10 2v16M2 8h16"/></svg>`;
}

async function downloadPreview(config, photo, toast) {
  const button = $('#download-preview');
  button.disabled = true;
  try {
    if (!photo.complete || !photo.naturalWidth) await new Promise((resolve, reject) => {
      photo.addEventListener('load', resolve, { once: true });
      photo.addEventListener('error', reject, { once: true });
    });
    const canvas = document.createElement('canvas');
    canvas.width = 1600;
    canvas.height = 900;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas not available');
    if (config.ambianceId === 'dusk') context.filter = 'sepia(0.25) saturate(1.2) brightness(0.82) contrast(1.07)';
    context.drawImage(photo, 0, 0, 1600, 900);
    context.filter = 'none';
    const svgImage = new Image();
    const url = URL.createObjectURL(new Blob([createFenceSvg(config, { idPrefix: 'export' })], { type: 'image/svg+xml;charset=utf-8' }));
    try {
      await new Promise((resolve, reject) => {
        svgImage.onload = resolve;
        svgImage.onerror = reject;
        svgImage.src = url;
      });
      context.drawImage(svgImage, 0, 0, 1600, 900);
    } finally { URL.revokeObjectURL(url); }
    const imageBlob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!imageBlob) throw new Error('Export unavailable');
    const downloadUrl = URL.createObjectURL(imageBlob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `cloture-therrien-${config.materialId}-${config.finishId}.png`;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(downloadUrl), 2000);
    toast('Aperçu PNG téléchargé.');
  } catch (error) {
    console.error('[Studio] Export error', error);
    toast('L’export est indisponible sur ce navigateur.');
  } finally { button.disabled = false; }
}
